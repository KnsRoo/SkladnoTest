import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue';
import Landing from '../views/Landing.vue';
import jsonData from '../../data.json';

const getLanding = (path) => jsonData.landings.find(landing => landing.path === path);
const getAdvantages = (name) => jsonData.advantages.find(advantages => advantages.name === name).list;
const getLinks = () => {
  return jsonData.landings.map((item) => {
    return {
      name: item.title,
      path: item.path
    }
  })
};

const routes = [
  {
    path: '/',
    component: Home,
    props: () => {
      return { links: getLinks() };
    },
  },
  {
    path: '/:id',
    component: Landing,
    props: route => {
      const landingData = getLanding(route.params.id);
      const advantages = getAdvantages(landingData.advantages);

      return {
        title: landingData.title,
        image: landingData.image,
        benefit: landingData.benefit,
        advantages: advantages,
      };
    },
    beforeEnter: (to, from, next) => {
      const landing = getLanding(to.params.id);
      if (landing) next();
      else next('/')
    }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
