<template>
  <Header />
  <div class="content">
    <div class="content__container">
      <Headline :title="title" :image="image" :benefit="benefit" :advantages="advantages" />
      <Request />
      <Contacts />
    </div>
  </div>
  <Footer />
</template>

<script>
import Header from "../components/Header";
import Headline from "../components/Headline";
import Request from "../components/Request";
import Contacts from "../components/Contacts";
import Footer from "../components/Footer";

export default {
  name: "Landing",
  components: { Header, Headline, Request, Contacts, Footer },
  props: {
    title: String,
    image: String,
    benefit: String,
    advantages: Array,
  },
};
</script>

<style>
.content {
  justify-content: center;
}

.content__container {
  flex-direction: column;
  justify-content: center;
  width: 1120px;
  padding: 20px 10px;
}
</style>