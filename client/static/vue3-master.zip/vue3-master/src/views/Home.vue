<template>
  <ul>
    <li v-for="(link, idx) in links" :key="idx">
      <a :href="'/' + link.path">{{ link.name }}</a>
    </li>
  </ul>
</template>

<script>
export default {
  name: "Home",
  components: {},
  props: {
    links: Array,
  },
  data: function () {
    console.log(this.links);
    return {};
  },
};
</script>
